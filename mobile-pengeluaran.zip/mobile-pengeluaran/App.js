import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

// Kita akan membuat file-file ini di langkah selanjutnya
import DaftarPengeluaran from './screens/DaftarPengeluaran';
import TambahPengeluaran from './screens/TambahPengeluaran';
import DetailPengeluaran from './screens/DetailPengeluaran';
import UbahPengeluaran from './screens/UbahPengeluaran';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator 
        initialRouteName="Daftar"
        screenOptions={{
          headerStyle: { backgroundColor: '#F8F9FA' },
          headerTintColor: '#111827',
          headerTitleStyle: { fontWeight: 'bold' },
          headerShadowVisible: false, // Menghilangkan garis batas bawah header agar rapi
        }}
      >
        <Stack.Screen 
          name="Daftar" 
          component={DaftarPengeluaran} 
          options={{ title: 'Pengeluaran' }} 
        />
        <Stack.Screen 
          name="Tambah" 
          component={TambahPengeluaran} 
          options={{ title: 'Tambah pengeluaran' }} 
        />
        <Stack.Screen 
          name="Detail" 
          component={DetailPengeluaran} 
          options={{ title: 'Detail pengeluaran' }} 
        />
        <Stack.Screen 
          name="Ubah" 
          component={UbahPengeluaran} 
          options={{ title: 'Ubah pengeluaran' }} 
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}