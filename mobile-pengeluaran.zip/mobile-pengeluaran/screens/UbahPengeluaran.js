import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ActivityIndicator, Alert } from 'react-native';
import { api } from '../services/api';

export default function UbahPengeluaran({ navigation, route }) {
  // Menerima data 'detail' yang dilempar dari halaman DetailPengeluaran
  const { detail } = route.params;

  // Mengisi state awal menggunakan data asli dari database
  const [judul, setJudul] = useState(detail.judul);
  const [nominal, setNominal] = useState(detail.nominal.toString());
  
  // State untuk validasi dan efek loading
  const [errorJudul, setErrorJudul] = useState('');
  const [errorNominal, setErrorNominal] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Format tanggal untuk tampilan yang terkunci
  const tanggalFormat = new Date(detail.tanggal).toLocaleDateString('id-ID', {
    day: 'numeric', month: 'long', year: 'numeric'
  });

  const handleSimpan = async () => {
    let isValid = true;

    // Validasi Judul
    if (!judul.trim()) {
      setErrorJudul('Judul wajib diisi');
      isValid = false;
    } else {
      setErrorJudul('');
    }

    // Validasi Nominal
    const nominalInt = parseInt(nominal, 10);
    if (!nominal || isNaN(nominalInt) || nominalInt < 1) {
      setErrorNominal('Nominal harus positif, minimal 1');
      isValid = false;
    } else {
      setErrorNominal('');
    }

    if (!isValid) return;

    setIsSubmitting(true);

    try {
      // Sesuai desain, kategori dan tanggal tidak diubah, hanya judul dan nominal
      await api.ubahPengeluaran(detail.id, {
        judul: judul,
        nominal: nominalInt,
        id_kategori: detail.id_kategori // Mengirim ulang id_kategori lama agar tidak null/berubah di backend
      });
      
      // Jika berhasil, kembali ke halaman detail
      navigation.goBack();
      
    } catch (error) {
      Alert.alert('Gagal', 'Terjadi kesalahan saat mengubah data ke server.');
      setIsSubmitting(false);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.formSection}>
        <Text style={styles.headerTitle}>Ubah pengeluaran</Text>
        <Text style={styles.subHeader}>Judul dan nominal saja</Text>

        {/* Input Judul */}
        <Text style={styles.label}>Judul</Text>
        <TextInput 
          style={[styles.input, errorJudul ? styles.inputError : null]} 
          value={judul}
          onChangeText={(text) => {
            setJudul(text);
            if (errorJudul) setErrorJudul('');
          }}
          editable={!isSubmitting}
        />
        {errorJudul ? <Text style={styles.errorText}>▲ {errorJudul}</Text> : null}

        {/* Input Nominal */}
        <Text style={styles.label}>Nominal (rupiah)</Text>
        <TextInput 
          style={[styles.input, errorNominal ? styles.inputError : null]} 
          keyboardType="numeric"
          value={nominal}
          onChangeText={(text) => {
            setNominal(text);
            if (errorNominal) setErrorNominal('');
          }}
          editable={!isSubmitting}
        />
        {errorNominal ? <Text style={styles.errorText}>▲ {errorNominal}</Text> : null}

        {/* Kategori (Terkunci) */}
        <Text style={styles.label}>Kategori</Text>
        <View style={styles.inputLocked}>
          {/* Menampilkan ID atau nama kategori yang ada */}
          <Text style={styles.textLocked}>{detail.kategori_nama || detail.nama_kategori || `ID: ${detail.id_kategori || '-'}`}</Text>
        </View>
        <Text style={styles.helperText}>Terkunci - kategori tidak dapat diubah lewat PUT</Text>

        {/* Tanggal (Terkunci) */}
        <Text style={styles.label}>Tanggal</Text>
        <View style={styles.inputLocked}>
          <Text style={styles.textLocked}>{tanggalFormat}</Text>
        </View>
        <Text style={styles.helperText}>Terkunci - ditetapkan server</Text>
      </View>

      {/* Bagian Tombol Bawah */}
      <View style={styles.footer}>
        <TouchableOpacity 
          style={[styles.primaryButton, isSubmitting && styles.buttonDisabled]}
          onPress={handleSimpan}
          disabled={isSubmitting}
        >
          <Text style={styles.primaryButtonText}>
            {isSubmitting ? 'Menyimpan...' : 'Simpan perubahan'}
          </Text>
        </TouchableOpacity>
        
        {!isSubmitting && (
          <TouchableOpacity 
            style={styles.secondaryButton} 
            onPress={() => navigation.goBack()}
          >
            <Text style={styles.secondaryButtonText}>Batal</Text>
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8F9FA', padding: 20, justifyContent: 'space-between' },
  formSection: { flex: 1 },
  headerTitle: { fontSize: 24, fontWeight: 'bold', color: '#111827', marginBottom: 4 },
  subHeader: { fontSize: 14, color: '#6B7280', marginBottom: 24 },
  label: { fontSize: 14, fontWeight: 'bold', color: '#374151', marginBottom: 8 },
  input: { backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#D1D5DB', borderRadius: 8, paddingHorizontal: 16, paddingVertical: 12, marginBottom: 16, fontSize: 16, color: '#111827' },
  inputError: { borderColor: '#DC2626', marginBottom: 4 },
  errorText: { color: '#DC2626', fontSize: 12, fontWeight: 'bold', marginBottom: 16 },
  inputLocked: { backgroundColor: '#F3F4F6', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 8, paddingHorizontal: 16, paddingVertical: 12, marginBottom: 4 },
  textLocked: { fontSize: 16, color: '#6B7280' },
  helperText: { fontSize: 12, color: '#6B7280', marginBottom: 16 },
  footer: { paddingTop: 10 },
  primaryButton: { backgroundColor: '#107C61', paddingVertical: 14, borderRadius: 8, alignItems: 'center', marginBottom: 10 },
  buttonDisabled: { backgroundColor: '#85BEB0' },
  primaryButtonText: { color: '#FFFFFF', fontWeight: 'bold', fontSize: 16 },
  secondaryButton: { backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#107C61', paddingVertical: 14, borderRadius: 8, alignItems: 'center' },
  secondaryButtonText: { color: '#107C61', fontWeight: 'bold', fontSize: 16 },
});