import React, { useState, useCallback } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Modal, ActivityIndicator, Alert } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { api } from '../services/api';

export default function DetailPengeluaran({ navigation, route }) {
  const { id } = route.params; 

  const [detail, setDetail] = useState(null);
  const [loading, setLoading] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  // Ambil data detail dari backend
  const fetchDetail = async () => {
    setLoading(true);
    try {
      const result = await api.getDetailPengeluaran(id);
      // Backend biasanya mengirim di dalam array [0] jika pakai query WHERE id = ?
      const dataAsli = Array.isArray(result.data || result) ? (result.data || result)[0] : (result.data || result);
      setDetail(dataAsli);
    } catch (error) {
      console.error(error);
      Alert.alert('Gagal', 'Tidak dapat memuat detail pengeluaran');
    } finally {
      setLoading(false);
    }
  };

  // Gunakan useFocusEffect agar data selalu ter-refresh jika kita kembali dari halaman Ubah
  useFocusEffect(
    useCallback(() => {
      fetchDetail();
    }, [id])
  );

  // Fungsi Hapus Data
  const handleHapus = async () => {
    setIsDeleting(true);
    try {
      await api.hapusPengeluaran(id);
      setModalVisible(false);
      navigation.goBack(); // Kembali ke halaman utama setelah sukses dihapus
    } catch (error) {
      Alert.alert('Gagal', 'Terjadi kesalahan saat menghapus data');
      setIsDeleting(false);
    }
  };

  if (loading) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator size="large" color="#107C61" />
      </View>
    );
  }

  // Jika data terhapus atau tidak ditemukan
  if (!detail) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <Text style={{ fontSize: 40, marginBottom: 10 }}>?</Text>
        <Text style={styles.modalTitle}>Data tidak ditemukan</Text>
        <Text style={styles.helperText}>Pengeluaran ini mungkin sudah dihapus.</Text>
        <TouchableOpacity style={styles.primaryButton} onPress={() => navigation.goBack()}>
          <Text style={styles.primaryButtonText}>Kembali ke daftar</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const tanggalFormat = new Date(detail.tanggal).toLocaleDateString('id-ID', {
    day: 'numeric', month: 'long', year: 'numeric'
  });

  return (
    <View style={styles.container}>
      <Text style={styles.headerTitle}>Detail pengeluaran</Text>
      
      <View style={styles.card}>
        <View style={styles.detailRow}>
          <Text style={styles.label}>Judul</Text>
          <Text style={styles.value}>{detail.judul}</Text>
        </View>

        <View style={styles.detailRow}>
          <Text style={styles.label}>Nominal</Text>
          <Text style={styles.value}>Rp {Number(detail.nominal).toLocaleString('id-ID')}</Text>
        </View>

        <View style={styles.detailRow}>
          <Text style={styles.label}>Tanggal</Text>
          <Text style={styles.value}>{tanggalFormat}</Text>
        </View>

        <View style={styles.detailRow}>
          <Text style={styles.label}>ID kategori</Text>
          <Text style={styles.value}>{detail.id_kategori || 'Tanpa kategori'}</Text>
        </View>

        <View style={[styles.detailRow, { borderBottomWidth: 0, paddingBottom: 0 }]}>
          <Text style={styles.label}>Catatan</Text>
          <Text style={[styles.value, { fontStyle: 'italic', color: '#6B7280' }]}>
            {detail.catatan || 'Belum ada catatan'}
          </Text>
        </View>
      </View>

      <Text style={styles.helperText}>
        Nama kategori belum tersedia pada respons detail. Layar menampilkan ID apa adanya.
      </Text>

      <View style={styles.footer}>
        <TouchableOpacity 
          style={styles.primaryButton}
          onPress={() => navigation.navigate('Ubah', { detail: detail })}
        >
          <Text style={styles.primaryButtonText}>Ubah</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={styles.dangerButton}
          onPress={() => setModalVisible(true)}
        >
          <Text style={styles.dangerButtonText}>Hapus</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={styles.secondaryButton}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.secondaryButtonText}>Kembali</Text>
        </TouchableOpacity>
      </View>

      {/* Modal Konfirmasi Hapus */}
      <Modal visible={modalVisible} animationType="fade" transparent={true}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Hapus {detail.judul}?</Text>
            <Text style={styles.modalText}>
              Pengeluaran Rp {Number(detail.nominal).toLocaleString('id-ID')} tanggal {tanggalFormat} akan dihapus permanen.
            </Text>

            <TouchableOpacity 
              style={[styles.dangerButton, { marginBottom: 10 }, isDeleting && { backgroundColor: '#F87171' }]}
              onPress={handleHapus}
              disabled={isDeleting}
            >
              <Text style={styles.dangerButtonText}>
                {isDeleting ? 'Menghapus...' : 'Hapus'}
              </Text>
            </TouchableOpacity>

            <TouchableOpacity 
              style={styles.secondaryButton}
              onPress={() => setModalVisible(false)}
              disabled={isDeleting}
            >
              <Text style={styles.secondaryButtonText}>Batal</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

// Styling tetap sama persis
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8F9FA', padding: 20 },
  headerTitle: { fontSize: 24, fontWeight: 'bold', color: '#111827', marginBottom: 20 },
  card: { backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 8, padding: 16, marginBottom: 12 },
  detailRow: { borderBottomWidth: 1, borderBottomColor: '#F3F4F6', paddingBottom: 12, marginBottom: 12 },
  label: { fontSize: 12, fontWeight: 'bold', color: '#6B7280', marginBottom: 4 },
  value: { fontSize: 16, color: '#111827' },
  helperText: { fontSize: 12, color: '#6B7280', marginBottom: 24 },
  footer: { marginTop: 'auto' },
  primaryButton: { backgroundColor: '#107C61', paddingVertical: 14, borderRadius: 8, alignItems: 'center', marginBottom: 10, width: '100%' },
  primaryButtonText: { color: '#FFFFFF', fontWeight: 'bold', fontSize: 16 },
  dangerButton: { backgroundColor: '#DC2626', paddingVertical: 14, borderRadius: 8, alignItems: 'center', marginBottom: 10 },
  dangerButtonText: { color: '#FFFFFF', fontWeight: 'bold', fontSize: 16 },
  secondaryButton: { backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#107C61', paddingVertical: 14, borderRadius: 8, alignItems: 'center' },
  secondaryButtonText: { color: '#107C61', fontWeight: 'bold', fontSize: 16 },
  modalOverlay: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: 'rgba(0,0,0,0.4)', padding: 20 },
  modalContent: { backgroundColor: '#FFFFFF', borderRadius: 16, padding: 24, width: '100%' },
  modalTitle: { fontSize: 20, fontWeight: 'bold', color: '#111827', marginBottom: 8 },
  modalText: { fontSize: 14, color: '#4B5563', marginBottom: 24, lineHeight: 20 }
});