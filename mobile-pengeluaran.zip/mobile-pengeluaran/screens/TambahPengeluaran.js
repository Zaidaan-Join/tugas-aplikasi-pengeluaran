import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Modal, ActivityIndicator, Alert } from 'react-native';
import { api } from '../services/api';

export default function TambahPengeluaran({ navigation }) {
  const [judul, setJudul] = useState('');
  const [nominal, setNominal] = useState('');
  const [kategori, setKategori] = useState('');
  
  const [modalVisible, setModalVisible] = useState(false);
  
  // State untuk validasi dan efek loading
  const [errorJudul, setErrorJudul] = useState('');
  const [errorNominal, setErrorNominal] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const daftarKategori = ['Pendidikan', 'Makanan', 'Transport', 'Hiburan'];

  // Fungsi untuk mengeksekusi penyimpanan ke backend
  const handleSimpan = async () => {
    let isValid = true;

    // Validasi Judul
    if (!judul.trim()) {
      setErrorJudul('Judul wajib diisi');
      isValid = false;
    } else {
      setErrorJudul('');
    }

    // Validasi Nominal
    const nominalInt = parseInt(nominal, 10);
    if (!nominal || isNaN(nominalInt) || nominalInt < 1) {
      setErrorNominal('Nominal harus positif, minimal 1');
      isValid = false;
    } else {
      setErrorNominal('');
    }

    // Berhenti jika ada error validasi
    if (!isValid) return;

    // Aktifkan status loading
    setIsSubmitting(true);

    // Menerjemahkan nama kategori ke id_kategori sesuai db_pengeluaran.sql
    let id_kategori = null;
    if (kategori === 'Pendidikan') id_kategori = 1;
    else if (kategori === 'Makanan') id_kategori = 2;
    else if (kategori === 'Transport') id_kategori = 3;
    else if (kategori === 'Hiburan') id_kategori = 4;

    try {
      // Panggil API untuk menyimpan data
      await api.tambahPengeluaran({
        judul: judul,
        nominal: nominalInt,
        id_kategori: id_kategori
      });
      
      // Jika sukses, kembali ke halaman daftar. 
      // (Halaman daftar akan otomatis me-refresh data berkat useFocusEffect yang kita buat sebelumnya)
      navigation.goBack();
      
    } catch (error) {
      Alert.alert('Gagal', 'Terjadi kesalahan saat menyimpan data ke server.');
    } finally {
      setIsSubmitting(false); // Matikan loading jika gagal (jika sukses sudah keburu pindah halaman)
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.formSection}>
        <Text style={styles.headerTitle}>Tambah pengeluaran</Text>
        <Text style={styles.subHeader}>
          {isSubmitting ? 'Mengirim ke server...' : 'Periksa sebelum menyimpan'}
        </Text>

        {/* Input Judul */}
        <Text style={styles.label}>Judul</Text>
        <TextInput 
          style={[styles.input, errorJudul ? styles.inputError : null]} 
          placeholder="Contoh: Makan siang" 
          value={judul}
          onChangeText={(text) => {
            setJudul(text);
            if (errorJudul) setErrorJudul('');
          }}
          editable={!isSubmitting} // Kunci input saat loading
        />
        {errorJudul ? <Text style={styles.errorText}>▲ {errorJudul}</Text> : null}

        {/* Input Nominal */}
        <Text style={styles.label}>Nominal (rupiah)</Text>
        <TextInput 
          style={[styles.input, errorNominal ? styles.inputError : null]} 
          placeholder="20000" 
          keyboardType="numeric"
          value={nominal}
          onChangeText={(text) => {
            setNominal(text);
            if (errorNominal) setErrorNominal('');
          }}
          editable={!isSubmitting}
        />
        {errorNominal ? <Text style={styles.errorText}>▲ {errorNominal}</Text> : null}

        {/* Pemilih Kategori */}
        <Text style={styles.label}>Kategori (opsional)</Text>
        <TouchableOpacity 
          style={styles.inputPicker} 
          onPress={() => !isSubmitting && setModalVisible(true)}
        >
          <Text style={{ color: kategori ? '#111827' : '#6B7280', fontSize: 16 }}>
            {kategori ? kategori : 'Tanpa kategori'}
          </Text>
          <Text style={{ color: '#6B7280', fontSize: 16 }}>›</Text>
        </TouchableOpacity>
        
        {isSubmitting ? (
          <View style={styles.loadingContainer}>
             <ActivityIndicator size="large" color="#107C61" />
             <Text style={styles.loadingText}>Menyimpan pengeluaran...</Text>
          </View>
        ) : (
          <Text style={styles.helperText}>Tanggal diisi otomatis oleh server saat data tersimpan.</Text>
        )}
      </View>

      {/* Bagian Tombol Bawah */}
      <View style={styles.footer}>
        <TouchableOpacity 
          style={[styles.primaryButton, isSubmitting && styles.buttonDisabled]}
          onPress={handleSimpan}
          disabled={isSubmitting} // Nonaktifkan tombol saat loading
        >
          <Text style={styles.primaryButtonText}>
            {isSubmitting ? 'Menyimpan' : 'Simpan'}
          </Text>
        </TouchableOpacity>
        
        {isSubmitting && (
           <Text style={styles.helperTextCenter}>Tombol dinonaktifkan agar data tidak terkirim dua kali</Text>
        )}

        {!isSubmitting && (
          <TouchableOpacity 
            style={styles.secondaryButton} 
            onPress={() => navigation.goBack()}
          >
            <Text style={styles.secondaryButtonText}>Kembali</Text>
          </TouchableOpacity>
        )}
      </View>

      {/* Modal Popup untuk Pemilihan Kategori */}
      <Modal visible={modalVisible} animationType="slide" transparent={true}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Pilih kategori</Text>
            
            <TouchableOpacity 
              style={styles.categoryItem} 
              onPress={() => { setKategori(''); setModalVisible(false); }}
            >
              <Text style={styles.categoryText}>Tanpa kategori</Text>
            </TouchableOpacity>

            {daftarKategori.map((item, index) => (
              <TouchableOpacity 
                key={index} 
                style={styles.categoryItem} 
                onPress={() => { setKategori(item); setModalVisible(false); }}
              >
                <Text style={styles.categoryText}>{item}</Text>
              </TouchableOpacity>
            ))}

            <TouchableOpacity 
              style={[styles.secondaryButton, { marginTop: 20 }]} 
              onPress={() => setModalVisible(false)}
            >
              <Text style={styles.secondaryButtonText}>Batal</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8F9FA', padding: 20, justifyContent: 'space-between' },
  formSection: { flex: 1 },
  headerTitle: { fontSize: 24, fontWeight: 'bold', color: '#111827', marginBottom: 4 },
  subHeader: { fontSize: 14, color: '#6B7280', marginBottom: 24 },
  label: { fontSize: 14, fontWeight: 'bold', color: '#374151', marginBottom: 8 },
  input: { backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#D1D5DB', borderRadius: 8, paddingHorizontal: 16, paddingVertical: 12, marginBottom: 16, fontSize: 16, color: '#111827' },
  inputError: { borderColor: '#DC2626', marginBottom: 4 },
  errorText: { color: '#DC2626', fontSize: 12, fontWeight: 'bold', marginBottom: 16 },
  inputPicker: { backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#D1D5DB', borderRadius: 8, paddingHorizontal: 16, paddingVertical: 12, marginBottom: 8, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  helperText: { fontSize: 12, color: '#6B7280' },
  helperTextCenter: { fontSize: 12, color: '#6B7280', textAlign: 'center', marginBottom: 10 },
  loadingContainer: { alignItems: 'center', marginTop: 40 },
  loadingText: { color: '#6B7280', marginTop: 10 },
  footer: { paddingTop: 10 },
  primaryButton: { backgroundColor: '#107C61', paddingVertical: 14, borderRadius: 8, alignItems: 'center', marginBottom: 10 },
  buttonDisabled: { backgroundColor: '#85BEB0' },
  primaryButtonText: { color: '#FFFFFF', fontWeight: 'bold', fontSize: 16 },
  secondaryButton: { backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#107C61', paddingVertical: 14, borderRadius: 8, alignItems: 'center' },
  secondaryButtonText: { color: '#107C61', fontWeight: 'bold', fontSize: 16 },
  modalOverlay: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.4)' },
  modalContent: { backgroundColor: '#FFFFFF', borderTopLeftRadius: 16, borderTopRightRadius: 16, padding: 24, paddingBottom: 40 },
  modalTitle: { fontSize: 20, fontWeight: 'bold', color: '#111827', marginBottom: 16 },
  categoryItem: { paddingVertical: 16, borderBottomWidth: 1, borderBottomColor: '#F3F4F6' },
  categoryText: { fontSize: 16, color: '#374151' },
});