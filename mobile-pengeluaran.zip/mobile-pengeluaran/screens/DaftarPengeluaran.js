import React, { useState, useCallback } from 'react';
import { View, Text, TouchableOpacity, FlatList, StyleSheet, ActivityIndicator } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { api } from '../services/api';

export default function DaftarPengeluaran({ navigation }) {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  // Fungsi untuk mengambil data dari backend
  const fetchData = async () => {
    setLoading(true);
    setError(false);
    try {
      const result = await api.getPengeluaran();
      // Asumsi backend mengembalikan array data langsung atau di dalam properti 'data'
      setData(result.data || result); 
    } catch (err) {
      console.error(err);
      setError(true);
    } finally {
      setLoading(false);
    }
  };

  // useFocusEffect akan memicu fetchData setiap kali halaman ini dibuka
  // Sangat berguna agar daftar otomatis refresh setelah kita menambah/mengubah data
  useFocusEffect(
    useCallback(() => {
      fetchData();
    }, [])
  );

  const renderItem = ({ item }) => {
    // Menangani format tanggal dari MySQL (ISO string)
    const tanggalFormat = new Date(item.tanggal).toLocaleDateString('id-ID', {
      day: 'numeric', month: 'short', year: 'numeric'
    });

    return (
      <View style={styles.card}>
        <Text style={styles.cardTitle}>{item.judul}</Text>
        <Text style={styles.cardNominal}>Rp {Number(item.nominal).toLocaleString('id-ID')}</Text>
        
        <View style={styles.cardFooter}>
          <View style={styles.badge}>
            {/* Menggunakan nama kategori jika di-join di backend, atau ID kategori jika tidak */}
            <Text style={styles.badgeText}>{item.kategori_nama || item.nama_kategori || `Kategori ID: ${item.id_kategori}`}</Text>
          </View>
          <Text style={styles.dateText}>{tanggalFormat}</Text>
        </View>
        
        <TouchableOpacity onPress={() => navigation.navigate('Detail', { id: item.id })}>
          <Text style={styles.linkText}>Lihat detail ›</Text>
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <Text style={styles.headerTitle}>Pengeluaran</Text>
      <Text style={styles.subHeader}>{data.length} catatan</Text>

      <TouchableOpacity 
        style={styles.primaryButton}
        onPress={() => navigation.navigate('Tambah')}
      >
        <Text style={styles.primaryButtonText}>Tambah pengeluaran</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.secondaryButton} onPress={fetchData}>
        <Text style={styles.secondaryButtonText}>Muat ulang</Text>
      </TouchableOpacity>

      {/* Menampilkan Status Loading, Error, atau Data Kosong */}
      {loading ? (
        <ActivityIndicator size="large" color="#107C61" style={{ marginTop: 50 }} />
      ) : error ? (
        <View style={styles.centerState}>
          <Text style={{ fontSize: 40, marginBottom: 10 }}>!</Text>
          <Text style={styles.centerTitle}>Gagal memuat pengeluaran</Text>
          <Text style={styles.centerDesc}>Server tidak merespons. Periksa koneksi.</Text>
        </View>
      ) : data.length === 0 ? (
        <View style={styles.centerState}>
          <Text style={{ fontSize: 40, marginBottom: 10 }}>+</Text>
          <Text style={styles.centerTitle}>Belum ada pengeluaran</Text>
          <Text style={styles.centerDesc}>Catatan pertamamu akan muncul di sini.</Text>
        </View>
      ) : (
        <FlatList
          data={data}
          keyExtractor={item => item.id.toString()}
          renderItem={renderItem}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: 20 }}
        />
      )}
    </View>
  );
}

// Styling tetap sama seperti sebelumnya
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8F9FA', paddingHorizontal: 20, paddingTop: 10 },
  headerTitle: { fontSize: 28, fontWeight: 'bold', color: '#111827' },
  subHeader: { fontSize: 14, color: '#6B7280', marginBottom: 20 },
  primaryButton: { backgroundColor: '#107C61', paddingVertical: 14, borderRadius: 8, alignItems: 'center', marginBottom: 10 },
  primaryButtonText: { color: '#FFFFFF', fontWeight: 'bold', fontSize: 16 },
  secondaryButton: { backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#107C61', paddingVertical: 14, borderRadius: 8, alignItems: 'center', marginBottom: 20 },
  secondaryButtonText: { color: '#107C61', fontWeight: 'bold', fontSize: 16 },
  card: { backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 8, padding: 16, marginBottom: 12 },
  cardTitle: { fontSize: 16, fontWeight: 'bold', color: '#111827', marginBottom: 4 },
  cardNominal: { fontSize: 20, fontWeight: 'bold', color: '#111827', marginBottom: 12 },
  cardFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  badge: { backgroundColor: '#F9FAFB', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 16, borderWidth: 1, borderColor: '#E5E7EB' },
  badgeText: { fontSize: 12, color: '#4B5563' },
  dateText: { fontSize: 12, color: '#6B7280' },
  linkText: { color: '#107C61', fontWeight: 'bold', fontSize: 14 },
  centerState: { flex: 1, justifyContent: 'center', alignItems: 'center', marginTop: 40 },
  centerTitle: { fontSize: 18, fontWeight: 'bold', color: '#111827', marginBottom: 8 },
  centerDesc: { fontSize: 14, color: '#6B7280', textAlign: 'center' }
});