const BASE_URL = 'http://192.168.1.15:3000'; 

export const api = {
  getPengeluaran: async () => {
    try {
      const response = await fetch(`${BASE_URL}/pengeluaran`);
      return await response.json();
    } catch (error) {
      console.error('Error getPengeluaran:', error);
      throw error;
    }
  },

  // FUNGSI BARU: Mengambil detail satu data berdasarkan ID
  getDetailPengeluaran: async (id) => {
    try {
      const response = await fetch(`${BASE_URL}/pengeluaran/${id}`);
      return await response.json();
    } catch (error) {
      console.error('Error getDetailPengeluaran:', error);
      throw error;
    }
  },

  tambahPengeluaran: async (data) => {
    try {
      const response = await fetch(`${BASE_URL}/pengeluaran`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      return await response.json();
    } catch (error) {
      console.error('Error tambahPengeluaran:', error);
      throw error;
    }
  },

  ubahPengeluaran: async (id, data) => {
    try {
      const response = await fetch(`${BASE_URL}/pengeluaran/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      return await response.json();
    } catch (error) {
      console.error('Error ubahPengeluaran:', error);
      throw error;
    }
  },

  hapusPengeluaran: async (id) => {
    try {
      const response = await fetch(`${BASE_URL}/pengeluaran/${id}`, {
        method: 'DELETE',
      });
      return await response.json();
    } catch (error) {
      console.error('Error hapusPengeluaran:', error);
      throw error;
    }
  }
};